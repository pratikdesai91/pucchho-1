"use client";

import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import ChatWindow from "@/components/ChatWindow";
import Account from "@/components/account";
import { useSession } from "next-auth/react";
import { useEffect } from "react";
import Profile from "@/components/Profile";

export type Message = {
  role: string;
  content: string;

  attachments?: {
    name: string;
    type: string;
    url?: string;
    fileObject?: File;
  }[];

  sources?: {
    title: string;
    link: string;
    snippet: string;
  }[];

  images?: {
    link: string;
    title: string;
  }[];

  versions?: string[];
  currentVersion?: number;
};

export type Chat = {
  id: string;
  title: string;
  messages: Message[];
};

export default function Home() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [showProfile, setShowProfile] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [currentChatId, setCurrentChatId] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("current_chat_id");
    }
    return null;
  });
  const currentChat = chats.find((chat) => chat.id === currentChatId);
  const { data: session } = useSession();
  const [hideLogin, setHideLogin] = useState(false);

  useEffect(() => {
    if (currentChatId) {
      localStorage.setItem("current_chat_id", currentChatId);
    }
  }, [currentChatId]);

  useEffect(() => {
    const loadChats = async () => {
      if (!session?.user?.email) return;

      const res = await fetch("/api/chat/load", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userEmail: session.user.email,
        }),
      });

      const data = await res.json();
      setChats((prev) => {
        if (prev.length > 0) return prev;
        return data.chats || [];
      });
    };

    loadChats();
  }, [session]);

  useEffect(() => {
    const stored = localStorage.getItem("guest_chats");
    if (stored) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setChats(JSON.parse(stored));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("guest_chats", JSON.stringify(chats));
  }, [chats]);

  return (
    <>
      <div className="relative flex h-dvh overflow-hidden">
        {/* Sidebar */}
        <div
          className={`
      fixed inset-y-0 left-0 z-40
      transform transition-transform duration-300 ease-out
      ${isMobileSidebarOpen ? "translate-x-0" : "-translate-x-full"}
      md:relative md:translate-x-0
    `}
        >
          <Sidebar
            chats={chats}
            setChats={setChats}
            setCurrentChatId={setCurrentChatId}
            currentChatId={currentChatId}
            onOpenProfile={() => setShowProfile(true)}
          />
        </div>

        {/* Overlay (Mobile only) */}
        {isMobileSidebarOpen && (
          <div
            className="fixed inset-0 bg-black/40 z-30 md:hidden"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
        )}

        {/* Chat */}
        <div className="flex-1 min-w-0 flex flex-col">
          <ChatWindow
            chats={chats}
            setChats={setChats}
            currentChat={currentChat}
            currentChatId={currentChatId}
            setCurrentChatId={setCurrentChatId}
            openSidebar={() => setIsMobileSidebarOpen(true)}
          />
        </div>
      </div>

      {showProfile && <Profile onClose={() => setShowProfile(false)} />}

      {/* 👇 Floating Right Login Panel */}

      {!session && !hideLogin && (
        <Account floating={true} onClose={() => setHideLogin(true)} />
      )}
    </>
  );
}
